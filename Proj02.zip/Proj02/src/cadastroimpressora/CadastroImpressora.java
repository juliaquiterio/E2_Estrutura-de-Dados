
package cadastroimpressora;

import tela.Principal;


public class CadastroImpressora {
    
    public static void main(String [] args){
        Principal principal = new Principal();
        principal.setVisible(true);
 
    
    }
    
}
