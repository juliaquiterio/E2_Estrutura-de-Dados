package temporaria;

import classes.Impressora;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class ControleImpressora {
    
    private ArrayList<Impressora> impressora = new ArrayList<>();
    
    public boolean salvar(Impressora ci){
        if (ci != null ){
            impressora.add(ci);
            return true;
        }else{
            return false;  
        }
    }
    public ArrayList<Impressora> retornaTodos (){
        return impressora;
    }
    
    
    private HashSet<String> impressora1 = new HashSet<>();
    private Map<String,String> numeroserie = new HashMap<>();
    private Map<String,String> material = new HashMap<>();
    private Map<String,Integer> peso = new HashMap<>();
    private Map<String,Integer> tamanho = new HashMap<>();
    
    public boolean Map(Impressora i){
        
        if (i != null){
            numeroserie.put("Número série", i.getNumeroserie());
            material.put("Material", i.getMaterial());
            peso.put("Peso", i.getPeso());
            tamanho.put("Tamanho", i.getTamanho());
                
            return true;
        } else{
            return false;
        }
    }
    
    public Map<String,String> retornaNumserie(){
        return numeroserie;
    }
    
    public Map<String,String> retornaMaterial(){
        return material;
    }
    
    public Map<String,Integer> retornaPeso(){
        return peso;
    }
    
    public Map<String,Integer> retornaTamanho(){
        return tamanho;
    }
    
    public HashSet<String> retornaHashSet(){
        return impressora1;
    }
    
    public boolean salvarHash(Impressora i){
        
        if (i != null){
            impressora1.add(i.getNumeroserie());
            return true;
            
        } else{
            return false;
        }
    }
    
    public ArrayList<Impressora> retornaImpressora(){
        return impressora;
        
    }
    
}

    
    


    
    
    
   
